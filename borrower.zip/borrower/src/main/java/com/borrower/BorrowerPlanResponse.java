package com.borrower;

import java.util.ArrayList;
import java.util.List;

public class BorrowerPlanResponse {

	List<BorrowerPlan> borrowerPlan = new ArrayList<>();

	public List<BorrowerPlan> getBorrowerPlan() {
		return borrowerPlan;
	}

	public BorrowerPlanResponse(List<BorrowerPlan> borrowerPlan) {
		super();
		this.borrowerPlan = borrowerPlan;
	}

	public void setBorrowerPlan(List<BorrowerPlan> borrowerPlan) {
		this.borrowerPlan = borrowerPlan;
	}

}
