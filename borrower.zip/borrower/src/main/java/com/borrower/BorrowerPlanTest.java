package com.borrower;

import java.time.LocalDateTime;
import java.util.List;

public class BorrowerPlanTest {

	public BorrowerPlanTest() {

	}

	// This is your endpoint in spring boot
	private static BorrowerPlanResponse borrowerPlanCalculation(double loanAmount, double nominalRate, Integer duration,
			LocalDateTime startDate) {
		BorrowerPlanService service = new BorrowerPlanService();
		List<BorrowerPlan> plans = service.borrowerPlanCalculation(loanAmount, nominalRate, duration, startDate);
		return new BorrowerPlanResponse(plans);
	}

	public static void main(String[] args) {

		double loanAmount = 5000;
		double nominalRate = 5;
		Integer duration = 24;

		BorrowerPlanResponse response = borrowerPlanCalculation(loanAmount, nominalRate, duration,
				LocalDateTime.of(2018, 1, 1, 0, 0, 0));
		
		List<BorrowerPlan> borrowerPlan = response.getBorrowerPlan();
		borrowerPlan.forEach(System.out::println);

	}

}
