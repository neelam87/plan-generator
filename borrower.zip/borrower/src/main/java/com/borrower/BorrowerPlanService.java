package com.borrower;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class BorrowerPlanService {
	/**
	 * Calculation of the borrower plan according to the input parameters.
	 * 
	 * @param loanAmount
	 * @param nominalRate
	 * @param duration
	 * @param startDate
	 * @return the list of plans.
	 */
	public List<BorrowerPlan> borrowerPlanCalculation(double loanAmount, double nominalRate, Integer duration,
			LocalDateTime startDate) {
		List<BorrowerPlan> plans = new ArrayList<BorrowerPlan>();
		while (loanAmount > 0) {

			double mensualyRate = (nominalRate / 100) / 12;
			double annuity = loanAmount * mensualyRate / (1 - Math.pow(1 + mensualyRate, -duration));
			annuity = Math.round(annuity * 100.0) / 100.0;

			double interest = nominalRate * 30 * loanAmount / 360 / 100;
			interest = Math.round(interest * 100.0) / 100.0;

			double principalAmount = annuity - interest;
			principalAmount = Math.round(principalAmount * 100.0) / 100.0;

			double remainingOutstandingPrincipal = loanAmount - principalAmount;
			remainingOutstandingPrincipal = Math.round(remainingOutstandingPrincipal * 100.0) / 100.0;

			BorrowerPlan plan = buildBorrowerPlanObject(loanAmount, startDate, annuity, interest, principalAmount,
					remainingOutstandingPrincipal);
			plans.add(plan);

			loanAmount = remainingOutstandingPrincipal;
			duration = duration - 1;
			startDate = startDate.plusMonths(1);

		}

		return plans;
	}

	private BorrowerPlan buildBorrowerPlanObject(double loanAmount, LocalDateTime startDate, double annuity,
			double interest, double principalAmount, double remainingOutstandingPrincipal) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
		BorrowerPlan plan = new BorrowerPlan();
		plan.setBorrowerPaymentAmount(annuity);
		plan.setDate(startDate.format(formatter));
		plan.setInitialOutstandingPrincipal(loanAmount);
		plan.setInterest(interest);
		plan.setRemainingOutstandingPrincipal(remainingOutstandingPrincipal);
		plan.setPrincipal(principalAmount);
		return plan;
	}
}
